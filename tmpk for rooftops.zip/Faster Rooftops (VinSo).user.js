// ==UserScript==
// @name Faster Rooftops (VinSo)
// @version 0.23
// @description VinSo Faster Rooftops
// @author Alex WWBDC
// @match https://apps.vinmanager.com/CarDashboard/Pages/LeadManagement/DeskLog.aspx
// @grant none
// ==/UserScript==

(function () {
"use strict";

// Function to extract the customer name and number from a viewItem link
function extractData(input) {
const regex = /javascript:top.viewItem\((\d+)\);">(.+)<\/a>/;
const match = input.match(regex);
return match ? { number: match[1], name: match[2] } : null;
}

// Function to open the link in a new tab
function openLink(number) {
window.open(
`https://apps.vinmanager.com/CarDashboard/Pages/CRM/CustomerDashboard.aspx?AutoLeadID=${number}`
);
}

// Function to open links in batches of 10
function openLinksInBatches(links, batchIndex, dialog) {
const customerLinks = Object.keys(links);
const batchSize = 10;
const startIndex = batchIndex * batchSize;
const endIndex = Math.min(startIndex + batchSize, customerLinks.length);

for (let i = startIndex; i < endIndex; i++) {
const customer = customerLinks[i];
const { number } = links[customer];
openLink(number);
}

if (endIndex < customerLinks.length) {
dialog.remove();
showBatchesDialog(links, batchIndex + 1);
}
}

// Function to create and display the first dialog box
function showConfirmationDialog(links) {
const customerLinks = Object.keys(links);
const totalLinks = customerLinks.length;
const batches = Math.ceil(totalLinks / 10);

// Show a warning if there are more than 10 links
if (totalLinks > 10) {
const dialogMessage = `Warning: Over 10 links detected. Open in batches of 10?\n\nDo you want to open ${totalLinks} links?`;
const openInBatches = confirm(dialogMessage);
if (openInBatches) {
showBatchesDialog(links, 0);
} else {
openAllLinks(links);
}
} else {
const dialogMessage = `Do you want to open ${totalLinks} links?`;
const openAll = confirm(dialogMessage);
if (openAll) {
openAllLinks(links);
}
}
}

// Function to open all links at once
function openAllLinks(links) {
for (const customer of Object.keys(links)) {
const { number } = links[customer];
openLink(number);
}
}

// Function to create and display the second dialog box
function showBatchesDialog(links, batchIndex) {
const customerLinks = Object.keys(links);
const batches = Math.ceil(customerLinks.length / 10);
const dialog = document.createElement("div");
dialog.style.position = "fixed";
dialog.style.top = "50%";
dialog.style.left = "50%";
dialog.style.transform = "translate(-50%, -50%)";
dialog.style.backgroundColor = "white";
dialog.style.padding = "10px"; // Reduce vertical padding
dialog.style.boxShadow = "0 0 10px rgba(0, 0, 0, 0.3)";
dialog.style.zIndex = "9999";

const table = document.createElement("table");
table.style.width = "100%";
table.style.borderCollapse = "collapse";

const customerList = [];
for (let batchIndex = 0; batchIndex < batches; batchIndex++) {
const startIndex = batchIndex * 10;
const endIndex = Math.min(startIndex + 10, customerLinks.length);
const batchCustomers = customerLinks.slice(startIndex, endIndex);
customerList.push(batchCustomers);
}

customerList.forEach((batchCustomers) => {
const row = document.createElement("tr");
batchCustomers.forEach((customer) => {
const cell = document.createElement("td");
cell.textContent = customer;
cell.style.padding = "5px";
row.appendChild(cell);
});
table.appendChild(row);
});

dialog.appendChild(table);

const cancelButton = document.createElement("button");
cancelButton.textContent = "Cancel";
cancelButton.addEventListener("click", () => dialog.remove());
dialog.appendChild(cancelButton);

const nextBatchButton = document.createElement("button");
nextBatchButton.textContent = "Click To Open Batches of 10"; // Change button text
nextBatchButton.addEventListener("click", () => {
dialog.remove();
openLinksInBatches(links, batchIndex, dialog);
});
dialog.appendChild(nextBatchButton);

document.body.appendChild(dialog);
}

// Function to convert viewItem links to clickable URLs
function convertLinks() {
const links = {};
const linkElements = document.getElementsByTagName("a");
for (const link of linkElements) {
const href = link.getAttribute("href");
if (href && href.startsWith("javascript:top.viewItem(")) {
const { number, name } = extractData(link.outerHTML);
if (number && name) {
links[name] = { number, element: link };
link.setAttribute(
"href",
`https://apps.vinmanager.com/CarDashboard/Pages/CRM/CustomerDashboard.aspx?AutoLeadID=${number}`
);
link.setAttribute("target", "_blank"); // Open links in a new tab
link.textContent = `Click to open ${name}`; // Update link text with the customer name
}
}
}

// Add a button to open the links
const openLinksButton = document.createElement("button");
openLinksButton.textContent = "Click to open the links";
openLinksButton.style.position = "fixed";
openLinksButton.style.bottom = "20px";
openLinksButton.style.right = "20px";
openLinksButton.addEventListener("click", () => {
showConfirmationDialog(links);
});

// Add the button to the body of the page
document.body.appendChild(openLinksButton);
}

// Wait for the page to fully load before converting the links
window.addEventListener("load", convertLinks);
})();
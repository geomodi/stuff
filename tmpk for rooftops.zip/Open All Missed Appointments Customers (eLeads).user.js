// ==UserScript==
// @name         Open All Missed Appointments Customers (eLeads)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  eLeads Faster Missed Appointments
// @author       Alex WWBDC
// @match        https://www.eleadcrm.com/evo2/fresh/eLead-V45/elead_track/reports/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Delay execution to ensure the page is fully loaded
    setTimeout(function(){
        let tdElements = Array.from(document.getElementsByTagName('td')); // get all 'td' elements
        let customerNames = [];
        tdElements.forEach((td) => {
            // check if td has the right align and valign
            if (td.getAttribute('align') === 'CENTER' && td.getAttribute('valign') === 'MIDDLE') {
                let link = td.querySelector('a'); // get the 'a' tag inside the 'td'
                if (link && link.getAttribute('onclick').startsWith('$.popupOppty')) { // check if it's the right 'a' tag
                    customerNames.push(link.textContent.trim()); // push the customer name into array
                }
            }
        });

        // create a modal to confirm opening all customer links
        let modalHTML = `
            <div id="modal" style="
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: rgba(0,0,0,0.4);
                display: flex;
                align-items: center;
                justify-content: center;
            ">
                <div style="
                    background-color: #fefefe;
                    margin: auto;
                    padding: 20px;
                    border: 1px solid #888;
                    width: 380px;
                    border-radius: 10px;
                    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                ">
                    <h2 style="margin-top: 0;">Open all customer links?</h2>
                    <p>The following customer links will be opened:</p>
                    <ul>${customerNames.map(name => `<li>${name}</li>`).join('')}</ul>
                    <button id="confirmOpen" style="
                        background-color: #4CAF50;
                        color: white;
                        padding: 10px 20px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 14px;
                        margin: 4px 2px;
                        cursor: pointer;
                        border-radius: 5px;
                    ">OK</button>
                    <button id="cancelOpen" style="
                        background-color: #f44336;
                        color: white;
                        padding: 10px 20px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 14px;
                        margin: 4px 2px;
                        cursor: pointer;
                        border-radius: 5px;
                    ">Cancel</button>
                </div>
            </div>
        `;

        // add the modal to the body
        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // add event listeners to the OK and Cancel buttons
        document.getElementById('confirmOpen').addEventListener('click', function() {
            tdElements.forEach((td) => {
                if (td.getAttribute('align') === 'CENTER' && td.getAttribute('valign') === 'MIDDLE') {
                    let link = td.querySelector('a');
                    if (link && link.getAttribute('onclick').startsWith('$.popupOppty')) {
                        link.click();
                    }
                }
            });
            // remove the modal
            document.body.removeChild(document.getElementById('modal'));

            // confirm that the links were opened
            let confirmModalHTML = `
                <div id="confirmModal" style="
                    position: fixed;
                    z-index: 1000;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    overflow: auto;
                    background-color: rgba(0,0,0,0.4);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                ">
                    <div style="
                        background-color: #fefefe;
                        margin: auto;
                        padding: 20px;
                        border: 1px solid #888;
                        width: 380px;
                        border-radius: 10px;
                        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                    ">
                        <h2 style="margin-top: 0;">All Customer Links Opened!</h2>
                        <p>The following customer links were opened:</p>
                        <ul>${customerNames.map(name => `<li>${name}</li>`).join('')}</ul>
                        <button id="confirmClose" style="
                            background-color: #4CAF50;
                            color: white;
                            padding: 10px 20px;
                            text-align: center;
                            text-decoration: none;
                            display: inline-block;
                            font-size: 14px;
                            margin: 4px 2px;
                            cursor: pointer;
                            border-radius: 5px;
                        ">Close</button>
                    </div>
                </div>
            `;
            // add the confirmation modal to the body
            document.body.insertAdjacentHTML('beforeend', confirmModalHTML);
            // add an event listener to the Close button
            document.getElementById('confirmClose').addEventListener('click', function() {
                document.body.removeChild(document.getElementById('confirmModal')); // remove the confirmation modal
            });
        });

        document.getElementById('cancelOpen').addEventListener('click', function() {
            document.body.removeChild(document.getElementById('modal')); // remove the modal
        });

    }, 3000); // delay for 3 seconds
})();

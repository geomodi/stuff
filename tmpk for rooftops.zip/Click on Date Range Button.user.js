// ==UserScript==
// @name         Click on Date Range Button
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Click on the Date Range button when it becomes available.
// @author       You
// @match        https://analytics.ringcentral.com/performance-report/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let attemptCount = 0;

    function clickOnElement(selector) {
        let element = document.querySelector(selector);
        if (element) {
            element.click();
            console.log(`Clicked on element with selector "${selector}".`);
            observer.disconnect(); // Disconnect the observer once the element is clicked
        } else {
            attemptCount++;
            console.log(`Attempt ${attemptCount}: Element with selector "${selector}" not found.`);
            if (attemptCount > 50) {  // Let's try 50 times before disconnecting
                observer.disconnect();
                console.log("Stopped observing after 50 unsuccessful attempts.");
            }
        }
    }

    // Set up the mutation observer to watch for changes in the document
    const observer = new MutationObserver(() => {
        clickOnElement('[data-test="DropdownWrapper"] button[data-test="button-default"]');
    });

    // Delay the observer by 5 seconds
    setTimeout(() => {
        observer.observe(document, { childList: true, subtree: true });
    }, 5000);

})();

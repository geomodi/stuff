// ==UserScript==
// @name         Auto Login for VinSo
// @version      0.1
// @description  Auto login for vinsolutions.signin.coxautoinc.com
// @author       Alex WWBDC
// @match        *://vinsolutions.signin.coxautoinc.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var vinUsers = [
        {name: 'Alpine Buick GMC', username: 'Worldwidebdc3106', password: 'P0assword1@'},
        {name: 'Alpine Ford', username: 'Wwbdc11467', password: 'Sales21@'},
        {name: 'Granger CDJR', username: 'worldwide.bdc14871', password: 'Sales123'},
        {name: 'Granger Chevrolet', username: 'worldwide.bdc', password: 'Granger1'},
        {name: 'Lehman Genesis Hyundai', username: 'snbdc', password: 'Morgan123'},
        {name: 'Mike Terry Chevy', username: 'MTCGWWBDC', password: 'Jimmy321'},
        {name: 'Steve Rayman Chevrolet', username: 'wwbdc95', password: 'Worldwide1'},
        {name: 'Subaru of North Miami', username: 'snbdc', password: 'Morgan123'}
    ];

    function simulateUserInput(input, value) {
        input.focus();
        for (let char of value.split('')) {
            document.execCommand('insertText', false, char);
        }
    }

    function vinsolutionsLogin(user) {
        let usernameField = document.getElementById("username");
        let signInBtn = document.getElementById("signIn");

        if (usernameField && usernameField.value === "") {
            simulateUserInput(usernameField, user.username);

            // Activate the button by simulating a backspace and re-adding the last character
            let lastChar = user.username.slice(-1);
            usernameField.value = user.username.slice(0, -1);
            setTimeout(() => {
                simulateUserInput(usernameField, lastChar);
                if (signInBtn) signInBtn.click();

                // Attempt to fill the password after a short delay
                setTimeout(() => {
                    let passwordField = document.getElementById("password");
                    if (passwordField && passwordField.value === "") {
                        simulateUserInput(passwordField, user.password);

                        // Activate the button by simulating a backspace and re-adding the last character
                        let passLastChar = user.password.slice(-1);
                        passwordField.value = user.password.slice(0, -1);
                        setTimeout(() => {
                            simulateUserInput(passwordField, passLastChar);
                            if (signInBtn) signInBtn.click();
                        }, 500);
                    }
                }, 500);
            }, 500);
        }
    }

function createModal() {
    var modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '30%';
    modal.style.right = '15px';
    modal.style.width = '330px';
    modal.style.height = '160px';
    modal.style.padding = '20px';
    modal.style.backgroundImage = 'linear-gradient(135deg, #f9f9f9, #e9e9e9)';
    modal.style.border = '1px solid #ccc';
    modal.style.zIndex = '9999';
    modal.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
    modal.style.borderRadius = '10px';
    modal.style.textAlign = 'center';

    var title = document.createElement('h2');
    title.textContent = "VinSo AutoLogin by Alex WWBDC";
    title.style.borderBottom = '1px solid #eee';
    title.style.paddingBottom = '5px';
    title.style.marginBottom = '5px';
    title.style.fontSize = '18px';
    title.style.color = '#333';
    title.style.textShadow = '1px 1px 2px rgba(0,0,0,0.1)';
    modal.appendChild(title);

    var select = document.createElement('select');
    select.style.width = '70%';
    select.style.height = '33px';
    select.style.marginBottom = '10px';
    select.style.fontSize = '14px';
    select.style.borderRadius = '5px';
    vinUsers.forEach(function(user) {
        var option = document.createElement('option');
        option.value = user.name;
        option.textContent = user.name;
        select.appendChild(option);
    });
    modal.appendChild(select);

    var okBtn = document.createElement('button');
    okBtn.textContent = "Login";
    okBtn.style.marginTop = '10px';
    okBtn.style.padding = '9px 18px';
    okBtn.style.backgroundColor = '#007bff';
    okBtn.style.color = 'white';
    okBtn.style.border = 'none';
    okBtn.style.borderRadius = '5px';
    okBtn.style.cursor = 'pointer';
    okBtn.style.transition = 'background-color 0.3s';
    okBtn.onmouseover = function() {
        this.style.backgroundColor = '#0056b3';
    };
    okBtn.onmouseout = function() {
        this.style.backgroundColor = '#007bff';
    };
    okBtn.onclick = function() {
        var selectedUser = vinUsers.find(u => u.name === select.value);
        if (selectedUser) {
            vinsolutionsLogin(selectedUser);
        }
    };
    modal.appendChild(okBtn);

    var logoImg = document.createElement('img');
    logoImg.src = 'https://drive.google.com/uc?export=view&id=1kojK1ZhUrrkQA0e62BBOJzF4KLMXxwEQ';
    logoImg.style.position = 'absolute';
    logoImg.style.bottom = '10px';
    logoImg.style.right = '10px';
    logoImg.style.width = '80px';
    logoImg.style.opacity = '0.8';
    modal.appendChild(logoImg);

    document.body.appendChild(modal);
}

    window.onload = function() {
        createModal();
    };

})();
// ==UserScript==
// @name         Rep -- Per Notes
// @namespace    tampermonkey
// @version      1.0
// @description  Types "Rep -- Per Notes" into specified textarea element and clicks on a link using XPath when a keyboard shortcut is pressed
// @match        https://www.eleadcrm.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Define the XPath to the link element
    const linkXPath = '/html/body/form/div[3]/table[1]/tbody/tr[2]/td[15]/a';

    // Add a keyboard shortcut to trigger the click on the link element
    document.addEventListener('keydown', event => {
        if (event.key === '0' && event.ctrlKey && event.altKey) {
            event.preventDefault(); // prevent default behavior of Ctrl+Alt+0
            const linkElement = document.evaluate(linkXPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            if (linkElement) {
                linkElement.click();
            }
        }
    });

    // Define the selector for the textarea element
    const textareaSelector = "#addUpdate > table > tbody > tr:nth-child(4) > td > div > textarea";

    // Type "David -- Per Notes" into the textarea element
    const textarea = document.querySelector(textareaSelector);
    if (textarea) {
        textarea.value = "Rep -- Per Notes";}
})();
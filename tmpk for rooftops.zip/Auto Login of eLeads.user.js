// ==UserScript==
// @name         Auto Login of eLeads
// @version      0.1
// @description  Auto login for retail.cdk.com with enhanced styling
// @author       Alex WWBDC
// @match        *://retail.cdk.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var users = [
        { name: "Broudy Nissan", username: "broudynissanwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Cronic Chevrolet", username: "kinunez@icloud.com", password: "Worldwide1!" },
        { name: "Cronic Nissan", username: "cronicnissanwwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Eastside Volkswagen", username: "eastsidevwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Fayetteville Dodge Ram", username: "Fayettevillewwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Hyundai of Greer", username: "hogwwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Keffer Volkswagen", username: "Keffervwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Kia of Greer", username: "kogwwbdc@gmail.com", password: "Worldwide5!" },
        { name: "Legacy CDJR", username: "legacycdjrwwbdc@gmail.com", password: "Worldwide5!" },
        { name: "Legacy Chevrolet", username: "Chevroletlegacy@gmail.com", password: "Worldwide1!" },
        { name: "Mazda of Columbia", username: "mazdacolumbiawwbdc@outlook.com", password: "Worldwide1!" },
        { name: "Mike Reichenbach Ford", username: "morgan.conway5@gmail.com", password: "Worldwide1!" },
        { name: "Mike Reichenback Volkswagen", username: "MikeVolkswwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Nissan of Greer", username: "NOGWWBDC@GMAIL.COM", password: "Worldwide123!" },
        { name: "Nissan of Hendersonville", username: "hendersonvillenis@gmail.com", password: "Worldwide1!" },
        { name: "Nissan of Lithia Springs", username: "nissanlithiawwbdc@gmail.com", password: "Worldwide2!" },
        { name: "Nissan of Newnan", username: "nissannewwwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Nissan of Orangeburg", username: "wwbdcOrangeburg@gmail.com", password: "Worldwide5!" },
        { name: "Nissan of Richmond", username: "kiomarisn@worldwidebdc.com", password: "Worldwide15!" },
        { name: "Nissan of South Morrow", username: "Nissansmorrow@gmail.com", password: "Worldwide1!" },
        { name: "Nissan of Union City", username: "nissanunionwwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Santee Automotive", username: "santeecdjr@gmail.com", password: "Worldwide3!" },
        { name: "Southtowne Hyundai of Newnan", username: "southtownenewnan1@outlook.com", password: "Worldwide11!" },
        { name: "Southtowne Hyundai of Riverdale", username: "southtowneriverdalewwbdc@outlook.com", password: "Alex123!" },
        { name: "Union City CDJR", username: "	unioncdjrwwbdc@gmail.com", password: "Worldwide1!" },
        { name: "Wade Ford", username: "wadefordbdc@gmail.com", password: "Worldwide1!" }
    ];

    users.sort((a, b) => a.name.localeCompare(b.name));

    function createModal() {
        var modal = document.createElement('div');
        modal.style.position = 'fixed';
        modal.style.top = '30%';
        modal.style.right = '15px';
        modal.style.width = '330px';
        modal.style.height = '130px';
        modal.style.padding = '20px';
        modal.style.backgroundImage = 'linear-gradient(135deg, #f9f9f9, #e9e9e9)';
        modal.style.border = '1px solid #ccc';
        modal.style.zIndex = '9999';
        modal.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
        modal.style.borderRadius = '10px';
        modal.style.textAlign = 'center';

        var title = document.createElement('h2');
        title.textContent = "CDK AutoLogin by Alex WWBDC";
        title.style.borderBottom = '1px solid #eee';
        title.style.paddingBottom = '10px';
        title.style.marginBottom = '10px';
        title.style.fontSize = '20px'; // increased font size
        title.style.color = '#333'; // dark gray color
        title.style.textShadow = '1px 1px 2px rgba(0,0,0,0.1)'; // subtle text shadow
        modal.appendChild(title);

        var select = document.createElement('select');
        select.style.marginBottom = '10px';
        select.style.borderRadius = '5px'; // rounded corners
        select.style.padding = '5px'; // padding for better look
        users.forEach(function(user) {
            var option = document.createElement('option');
            option.value = user.name;
            option.textContent = user.name;
            select.appendChild(option);
        });
        modal.appendChild(select);

        var okBtn = document.createElement('button');
        okBtn.textContent = "Login";
        okBtn.style.marginTop = '10px';
        okBtn.style.padding = '10px 20px';
        okBtn.style.backgroundColor = '#007bff';
        okBtn.style.color = 'white';
        okBtn.style.border = 'none';
        okBtn.style.borderRadius = '5px'; // rounded corners
        okBtn.style.cursor = 'pointer';
        okBtn.style.transition = 'background-color 0.3s'; // smooth transition
        okBtn.onmouseover = function() {
            this.style.backgroundColor = '#0056b3';
        };
        okBtn.onmouseout = function() {
            this.style.backgroundColor = '#007bff';
        };
        okBtn.onclick = function() {
            var selectedUser = users.find(u => u.name === select.value);
            if (selectedUser) {
                var usernameField = document.evaluate('//*[@id="okta-signin-username"]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                usernameField.value = selectedUser.username;
                var event = new Event('input', {
                    'bubbles': true,
                    'cancelable': true
                });
                usernameField.dispatchEvent(event);

                var passwordField = document.evaluate('//*[@id="okta-signin-password"]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                passwordField.value = selectedUser.password;
                passwordField.dispatchEvent(event);

                setTimeout(function() {
                    var submitBtn = document.evaluate('//*[@id="okta-signin-submit"]', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                    submitBtn.focus();
                    var clickEvent = new MouseEvent("click", {
                        "bubbles": true,
                        "cancelable": false
                    });
                    submitBtn.dispatchEvent(clickEvent);
                }, 2000);
            }
        };
        modal.appendChild(okBtn);

        var logoImg = document.createElement('img');
        logoImg.src = 'https://drive.google.com/uc?export=view&id=1kojK1ZhUrrkQA0e62BBOJzF4KLMXxwEQ';
        logoImg.style.position = 'absolute';
        logoImg.style.bottom = '10px';
        logoImg.style.right = '10px';
        logoImg.style.width = '100px';
        logoImg.style.opacity = '0.8'; // slight opacity
        modal.appendChild(logoImg);

        document.body.appendChild(modal);
    }

    window.onload = function() {
        createModal();
    };

})();
